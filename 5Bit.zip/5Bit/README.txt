To begin, click on 5bit Installer to install the program and a shortcut will be added to your Desktop. 
Click that to get started. 